<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public static function index(){
        return view('index');
    }

    public static function viewProducts(){
        $products = Product::paginate(15);
        return view('product', compact('products'));
    }

    public function store(Request $request){

        $request->validate([
            'category' => 'required|string',
            'name' => 'required|string|min:5|max:80',
            'price' => 'required|integer',
            'qty' => 'required|integer',
            'photo' => 'required'
        ]);

        Product::create([
            'category' => $request->input('category'),
            'name' => $request->input('name'),
            'price' => $request->input('price'),
            'qty' => $request->input('qty'),
            'photo' => $request->input('photo'),
        ]);
    }

    public function update(Product $product, Request $request){
        $product->category = $request->input('category');
        $product->name = $request->input('name');
        $product->price = $request->input('price');
        $product->qty = $request->input('qty');
        $product->photo = $request->input('photo');
        $product->save();
    }

    public function delete(Product $product){
        $product->delete();
        return redirect()->back();
    }
}
