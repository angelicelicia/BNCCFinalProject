<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('login');
    }

    public function store(Request $request)
    {
        //
        $request->validate([
            'email' => 'required|email',
            'password' => 'required'
        ],[
            'email.required' => 'email field must not be empty',
            'email.email' => 'invalid email',
            'password.required' => 'password field must not be empty'
        ]);

        if(Auth::attempt(['email' => '$request->email', 'password' => '$request->password', $request->remember])){

            if(Auth::user()->role == 'admin'){
                return redirect('adminPage');
            }
            else if(Auth::user()->role == 'user'){
                return redirect('userPage');
            }
        }
        return redirect()->back();

    }

    function logout(){
        Auth::logout();
        return redirect('manualLogin');
    }

    public function destroy($id)
    {
        //
    }
}
