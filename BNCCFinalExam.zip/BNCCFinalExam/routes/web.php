<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/loginController', [\App\Http\Controllers\LoginController::class, 'index']);
Route::post('/loginValidation', [\App\Http\Controllers\LoginController::class, 'store'])->name('validation');
Route::get('/logout', [\App\Http\Controllers\LoginController::class, 'logout'])->name('logout');

Route::get('/viewProducts', [App\Http\Controllers\ProductController::class, 'viewProducts']);
Route::get('/', [App\Http\Controllers\ProductController::class, 'index']);
Route::post('/delete', [ProductController::class, 'delete'])->name('delete');
Route::post('/update', [ProductController::class, 'update'])->name('update');
