@extends('template')

@section('title', 'home')

@section('content')
    <a href="viewAllocations">View Allocations</a>
    <a href="{{route('logout')}}">Logout</a>
@endsection
